# Expense Tracker (MERN)
> Full stack mobile app


```
### backend
cd __backend -> 
npm run server

### frontend
npm start

